/*
 * GlblInterrupt_Private.h
 *
 *  Created on: May 28, 2021
 *      Author: Eng_Fawzi
 */

#ifndef GLBLINTERRUPT_PRIVATE_H_
#define GLBLINTERRUPT_PRIVATE_H_

#define GLBLINT_SREG_REG				(*(volatile u8*)0x5F)
#define I_BIT_POS						(7)
#endif /* GLBLINTERRUPT_PRIVATE_H_ */
