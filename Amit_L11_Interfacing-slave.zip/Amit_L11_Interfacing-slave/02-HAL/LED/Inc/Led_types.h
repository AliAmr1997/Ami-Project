/*
 * Led_types.h
 *
 *  Created on: Apr 30, 2021
 *      Author: Eng_Fawzi
 */

#ifndef HAL_LED_INC_LED_TYPES_H_
#define HAL_LED_INC_LED_TYPES_H_

typedef enum {
	LED0,
	LED1,
	LED2
}Led_ID;

#endif /* HAL_LED_INC_LED_TYPES_H_ */
